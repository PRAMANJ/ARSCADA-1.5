var HOSTNAME="laptop-rlsqd170";
var PROJECTNAME="ars";
var PORT="8088";
var DEFAULT_TAGSFILE="C:\\\\ARS\\\\tags.txt";
var cycle_time=5;
