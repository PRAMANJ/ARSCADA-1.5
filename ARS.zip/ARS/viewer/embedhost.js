var HOSTNAME="LAPTOP-RLSQD170";
var PROJECTNAME="ars";
var PORT="8088";
var DEFAULT_TAGSFILE="C:\\\\ARS\\\\tags.txt";
